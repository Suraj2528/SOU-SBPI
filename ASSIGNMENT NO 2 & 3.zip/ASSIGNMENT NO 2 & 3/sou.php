

<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "sou";

// Create connection
$conn = new mysqli('localhost', 'root', '', 'sou');
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO student ( First Name, Last Name, Mobile Number, Enrollnment No)
VALUES ('John', 'Doe', 9737224139, 2202043006 )";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>



