<!DOCTYPE html>
<html lang="en">
<head>

    <title>Document</title>
</head>
<body>

<?php

$x = 2;
$Y = 5;


echo $x;
echo $Y;

?>
</body>
</html>